import React, { useState, useEffect } from "react";
import axios from "axios";

import Sidebar from "./Sidebar";
import Topbar from "./Topbar";

import "../css/clients.css";


function Clients() {


const [clients,setClients] = useState([]);

const [loading,setLoading] = useState(true);

const [search,setSearch] = useState("");


// View

const [showViewModal,setShowViewModal] = useState(false);

const [selectedClient,setSelectedClient] = useState(null);


// Edit

const [showEditModal,setShowEditModal] = useState(false);


const [editClient,setEditClient] = useState({});


// Delete

const [showDeleteModal,setShowDeleteModal] = useState(false);

const [deleteId,setDeleteId] = useState(null);


// Message

const [message,setMessage] = useState("");





// ===============================
// FETCH CLIENTS
// ===============================


const fetchClients = async()=>{


try{


setLoading(true);


const response = await axios.get(

"http://127.0.0.1:8000/api/clients"

);


setClients(response.data);



}

catch(error){

console.log(error);

}


finally{

setLoading(false);

}


};



useEffect(()=>{

fetchClients();

},[]);





// ===============================
// SEARCH
// ===============================


const filteredClients = clients.filter((client)=>{


const keyword = search.toLowerCase();


return (

client.company?.toLowerCase().includes(keyword)

||

client.contact?.toLowerCase().includes(keyword)

||

client.email?.toLowerCase().includes(keyword)

||

client.phone?.includes(search)

||

client.project?.toLowerCase().includes(keyword)


);


});





// ===============================
// VIEW
// ===============================


const handleView=(client)=>{


setSelectedClient(client);

setShowViewModal(true);


};






// ===============================
// EDIT
// ===============================


const handleEdit=(client)=>{


setEditClient(client);

setShowEditModal(true);


};





const handleEditChange=(e)=>{


setEditClient({

...editClient,

[e.target.name]:e.target.value

});


};






// ===============================
// UPDATE
// ===============================


const saveClient=async()=>{


try{


await axios.put(

`http://127.0.0.1:8000/api/clients/${editClient._id}`,

editClient

);



setMessage(
"Client updated successfully"
);



setShowEditModal(false);


fetchClients();



}

catch(error){

console.log(error);

setMessage(
"Update failed"
);


}



};






// ===============================
// DELETE
// ===============================


const handleDelete=(id)=>{


setDeleteId(id);

setShowDeleteModal(true);


};





const confirmDelete=async()=>{


try{


await axios.delete(

`http://127.0.0.1:8000/api/clients/${deleteId}`

);



setMessage(
"Client deleted successfully"
);



setShowDeleteModal(false);



fetchClients();



}

catch(error){

console.log(error);

}



};







if(loading){


return (

<div className="dashboard">


<Sidebar/>


<div className="dashboard-main">


<Topbar/>


<div className="dashboard-content">


<h3>
Loading Clients...
</h3>


</div>


</div>


</div>

);


}






return (


<div className="dashboard">


<Sidebar/>




<div className="dashboard-main">


<Topbar/>




<div className="dashboard-content">



<div className="clients-page">





<div className="clients-header">


<div>

<h2>
👥 Clients
</h2>


<p>
Manage converted clients from enquiries
</p>


</div>


</div>





{
message &&

<div className="success-message">

{message}

</div>

}






<input

className="search-box"

type="text"

placeholder="Search company, contact, email..."

value={search}

onChange={(e)=>setSearch(e.target.value)}

/>







<div className="table-container">


<table>



<thead>

<tr>

<th>S.No</th>

<th>Company</th>

<th>Contact</th>

<th>Email</th>

<th>Phone</th>

<th>Project</th>

<th>Status</th>

<th>Actions</th>


</tr>


</thead>





<tbody>



{

filteredClients.length===0 ?



<tr>

<td colSpan="8" className="no-data">

No Clients Found

</td>

</tr>



:



filteredClients.map((client,index)=>(



<tr key={client._id}>


<td>{index+1}</td>


<td>{client.company}</td>


<td>{client.contact}</td>


<td>{client.email}</td>


<td>{client.phone}</td>


<td>{client.project}</td>



<td>


<span className="status active">

{client.status || "Active"}

</span>


</td>



<td>


<div className="action-buttons">



<button

className="view-btn"

onClick={()=>handleView(client)}

>

View

</button>





<button

className="edit-btn"

onClick={()=>handleEdit(client)}

>

Edit

</button>





<button

className="delete-btn"

onClick={()=>handleDelete(client._id)}

>

Delete

</button>



</div>


</td>



</tr>



))


}



</tbody>




</table>


</div>






{/* ================= VIEW MODAL ================= */}



{

showViewModal && selectedClient &&



<div className="modal-overlay">


<div className="client-modal">



<h3>

Client Details

</h3>



<p>
<b>Company:</b> {selectedClient.company}
</p>


<p>
<b>Contact:</b> {selectedClient.contact}
</p>


<p>
<b>Email:</b> {selectedClient.email}
</p>


<p>
<b>Phone:</b> {selectedClient.phone}
</p>


<p>
<b>Project:</b> {selectedClient.project}
</p>


<p>
<b>Status:</b> {selectedClient.status}
</p>





<button

className="close-btn"

onClick={()=>setShowViewModal(false)}

>

Close

</button>




</div>


</div>


}






{/* ================= EDIT MODAL ================= */}



{

showEditModal &&



<div className="modal-overlay">


<div className="client-modal">



<h3>

Edit Client

</h3>




<input

name="company"

value={editClient.company || ""}

onChange={handleEditChange}

placeholder="Company"

/>




<input

name="contact"

value={editClient.contact || ""}

onChange={handleEditChange}

placeholder="Contact"

/>




<input

name="email"

value={editClient.email || ""}

onChange={handleEditChange}

placeholder="Email"

/>




<input

name="phone"

value={editClient.phone || ""}

onChange={handleEditChange}

placeholder="Phone"

/>




<input

name="project"

value={editClient.project || ""}

onChange={handleEditChange}

placeholder="Project"

/>




<select

name="status"

value={editClient.status || "Active"}

onChange={handleEditChange}

>


<option>
Active
</option>


<option>
Completed
</option>


<option>
Pending
</option>


</select>





<div className="modal-actions">



<button

className="save-btn"

onClick={saveClient}

>

Save

</button>




<button

className="close-btn"

onClick={()=>setShowEditModal(false)}

>

Cancel

</button>


</div>





</div>


</div>


}






{/* ================= DELETE MODAL ================= */}



{

showDeleteModal &&



<div className="modal-overlay">


<div className="client-modal">


<h3>

Delete Client?

</h3>


<p>

Are you sure you want to delete this client?

</p>



<div className="modal-actions">



<button

className="delete-btn"

onClick={confirmDelete}

>

Delete

</button>



<button

className="close-btn"

onClick={()=>setShowDeleteModal(false)}

>

Cancel

</button>



</div>


</div>


</div>


}








</div>



</div>


</div>


</div>


);


}



export default Clients;