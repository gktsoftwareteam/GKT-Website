import React, { useEffect, useState } from "react";
import axios from "axios";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import "../css/enquiries.css";

function Enquiries() {
  const [enquiries, setEnquiries] = useState([]);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("All");

  const [selectedEnquiry, setSelectedEnquiry] = useState(null);

  const [showViewModal, setShowViewModal] = useState(false);
  const [showReplyModal, setShowReplyModal] = useState(false);

  const [replyText, setReplyText] = useState("");

  // ===============================
  // Fetch Enquiries from FastAPI
  // ===============================

  const fetchEnquiries = async () => {
    try {
      const res = await axios.get(
        "http://127.0.0.1:8000/api/enquiries"
      );

      setEnquiries(res.data);
    } catch (error) {
      console.error("Error fetching enquiries:", error);
    }
  };

  useEffect(() => {
    fetchEnquiries();
  }, []);

  // ===============================
  // Search + Filter
  // ===============================

  const filteredData = enquiries.filter((item) => {
    const searchMatch =
      item.name?.toLowerCase().includes(search.toLowerCase()) ||
      item.email?.toLowerCase().includes(search.toLowerCase()) ||
      item.phone?.includes(search) ||
      item.service?.toLowerCase().includes(search.toLowerCase());

    const statusMatch =
      statusFilter === "All" || item.status === statusFilter;

    return searchMatch && statusMatch;
  });

  // ===============================
  // View
  // ===============================

  const handleView = (item) => {
    setSelectedEnquiry(item);
    setShowViewModal(true);
  };

  // ===============================
  // Reply
  // ===============================

  const handleReply = (item) => {
    setSelectedEnquiry(item);
    setReplyText("");
    setShowReplyModal(true);
  };

  // ===============================
  // Delete (Temporary - Frontend Only)
  // ===============================

  const handleDelete = (_id) => {
    if (window.confirm("Delete this enquiry?")) {
      setEnquiries((prev) =>
        prev.filter((item) => item._id !== _id)
      );
    }
  };

  // ===============================
  // Update Status (Temporary)
  // ===============================

  const updateStatus = (_id, value) => {
    const updated = enquiries.map((item) =>
      item._id === _id
        ? { ...item, status: value }
        : item
    );

    setEnquiries(updated);
  };

  // ===============================
  // Send Reply (Temporary)
  // ===============================

  const sendReply = () => {
    if (!replyText.trim()) {
      alert("Please type a reply.");
      return;
    }

    alert(`Reply sent successfully to ${selectedEnquiry.email}`);

    console.log({
      email: selectedEnquiry.email,
      message: replyText,
    });

    setReplyText("");
    setShowReplyModal(false);
  };

  return (
    <div className="dashboard">
  <Sidebar />

  <div className="dashboard-main">
    <Topbar />

    <div className="dashboard-content">

      <div className="enquiries-page">

        <div className="page-title">
          <h2>📩 Customer Enquiries</h2>
          <p>Manage all customer enquiries here.</p>
        </div>

        <div className="toolbar">

          <input
            type="text"
            placeholder="Search Name, Email, Phone..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option>All</option>
            <option>New</option>
            <option>In Progress</option>
            <option>Completed</option>
            <option>Waiting Client</option>
            <option>Rejected</option>
          </select>

        </div>

        <div className="table-container">

          <table>

            <thead>

              <tr>

                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Service</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>

              </tr>

            </thead>

            <tbody>

              {filteredData.length > 0 ? (

                filteredData.map((item) => (

                  <tr key={item._id}>

                    <td>{item._id.slice(-6)}</td>

                    <td>{item.name}</td>

                    <td>{item.email}</td>

                    <td>{item.phone}</td>

                    <td>{item.service}</td>

                    <td>
                      {item.createdAt
                        ? new Date(item.createdAt).toLocaleDateString()
                        : "-"}
                    </td>

                    <td>

                      <select
                        className="status-dropdown"
                        value={item.status}
                        onChange={(e) =>
                          updateStatus(item._id, e.target.value)
                        }
                      >
                        <option>New</option>
                        <option>In Progress</option>
                        <option>Completed</option>
                        <option>Waiting Client</option>
                        <option>Rejected</option>
                      </select>

                    </td>

                    <td>

                      <button
                        className="view-btn"
                        onClick={() => handleView(item)}
                      >
                        View
                      </button>

                      <button
                        className="reply-btn"
                        onClick={() => handleReply(item)}
                      >
                        Reply
                      </button>

                      <button
                        className="delete-btn"
                        onClick={() => handleDelete(item._id)}
                      >
                        Delete
                      </button>

                    </td>

                  </tr>

                ))

              ) : (

                <tr>

                  <td colSpan="8" style={{ textAlign: "center" }}>
                    No enquiries found.
                  </td>

                </tr>

              )}

            </tbody>

          </table>

        </div>

      </div>

      {/* ================= VIEW MODAL ================= */}
            {/* ================= VIEW MODAL ================= */}

      {showViewModal && selectedEnquiry && (
        <div className="modal-overlay">
          <div className="modal">

            <div className="modal-header">

              <h2>Customer Enquiry</h2>

              <button
                className="close-btn"
                onClick={() => setShowViewModal(false)}
              >
                ✖
              </button>

            </div>

            <div className="modal-body">

              <div className="info-row">
                <strong>Name :</strong>
                <span>{selectedEnquiry.name}</span>
              </div>

              <div className="info-row">
                <strong>Email :</strong>
                <span>{selectedEnquiry.email}</span>
              </div>

              <div className="info-row">
                <strong>Phone :</strong>
                <span>{selectedEnquiry.phone}</span>
              </div>

              <div className="info-row">
                <strong>Service :</strong>
                <span>{selectedEnquiry.service}</span>
              </div>

              <div className="info-row">
                <strong>Status :</strong>
                <span>{selectedEnquiry.status}</span>
              </div>

              <div className="info-row">
                <strong>Date :</strong>
                <span>
                  {selectedEnquiry.createdAt
                    ? new Date(selectedEnquiry.createdAt).toLocaleString()
                    : "-"}
                </span>
              </div>

              <div className="message-box">

                <h3>Customer Message</h3>

                <p>{selectedEnquiry.message}</p>

              </div>

            </div>

          </div>
        </div>
      )}

      {/* ================= REPLY MODAL ================= */}

      {showReplyModal && selectedEnquiry && (
        <div className="modal-overlay">

          <div className="modal">

            <div className="modal-header">

              <h2>Reply to Customer</h2>

              <button
                className="close-btn"
                onClick={() => setShowReplyModal(false)}
              >
                ✖
              </button>

            </div>

            <div className="modal-body">

              <div className="reply-info">

                <p>
                  <strong>Name :</strong> {selectedEnquiry.name}
                </p>

                <p>
                  <strong>Email :</strong> {selectedEnquiry.email}
                </p>

              </div>

              <textarea
                rows="8"
                className="reply-textarea"
                placeholder="Type your reply here..."
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
              />

              <div className="reply-actions">

                <button
                  className="cancel-btn"
                  onClick={() => setShowReplyModal(false)}
                >
                  Cancel
                </button>

                <button
                  className="send-btn"
                  onClick={sendReply}
                >
                  Send Reply
                </button>

              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  </div>
</div>
);
}

export default Enquiries;