import React, { useState } from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import "../css/projects.css";

const initialProjects = [
  {
    id: 1,
    name: "GKT Website",
    client: "ABC Technologies",
    developer: "Karthik",
    deadline: "15 Aug 2026",
    progress: 80,
    status: "In Progress",
  },
  {
    id: 2,
    name: "Restaurant Website",
    client: "Spice Garden",
    developer: "Rahul",
    deadline: "20 Aug 2026",
    progress: 40,
    status: "Pending",
  },
  {
    id: 3,
    name: "AI Chatbot",
    client: "XYZ Solutions",
    developer: "John",
    deadline: "01 Sep 2026",
    progress: 100,
    status: "Completed",
  },
];

function Projects() {
  const [projects, setProjects] = useState(initialProjects);
  const [search, setSearch] = useState("");

  const filteredProjects = projects.filter(
    (project) =>
      project.name.toLowerCase().includes(search.toLowerCase()) ||
      project.client.toLowerCase().includes(search.toLowerCase()) ||
      project.developer.toLowerCase().includes(search.toLowerCase())
  );

  const handleView = (project) => {
    alert(
      `Project: ${project.name}
Client: ${project.client}
Developer: ${project.developer}
Deadline: ${project.deadline}
Progress: ${project.progress}%
Status: ${project.status}`
    );
  };

  const handleEdit = (project) => {
    alert(`Edit ${project.name}`);
  };

  const handleDelete = (id) => {
    if (window.confirm("Delete this project?")) {
      setProjects(projects.filter((p) => p.id !== id));
    }
  };

  return (
    <div className="dashboard">

      <Sidebar />

      <div className="dashboard-main">

        <Topbar />

        <div className="dashboard-content">

          <div className="projects-page">

            <div className="projects-header">

              <h2>📁 Projects</h2>

              <button className="add-project-btn">
                + Add Project
              </button>

            </div>

            <input
              className="project-search"
              type="text"
              placeholder="Search Projects..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />

            <div className="table-container">

              <table>

                <thead>

                  <tr>
                    <th>ID</th>
                    <th>Project</th>
                    <th>Client</th>
                    <th>Developer</th>
                    <th>Deadline</th>
                    <th>Progress</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>

                </thead>

                <tbody>

                  {filteredProjects.map((project) => (

                    <tr key={project.id}>

                      <td>{project.id}</td>

                      <td>{project.name}</td>

                      <td>{project.client}</td>

                      <td>{project.developer}</td>

                      <td>{project.deadline}</td>

                      <td>

                        <div className="progress-bar">

                          <div
                            className="progress-fill"
                            style={{ width: `${project.progress}%` }}
                          />

                        </div>

                        <small>{project.progress}%</small>

                      </td>

                      <td>

                        <span
                          className={`status ${project.status
                            .replace(/\s+/g, "-")
                            .toLowerCase()}`}
                        >
                          {project.status}
                        </span>

                      </td>

                      <td>

                        <button
                          className="view-btn"
                          onClick={() => handleView(project)}
                        >
                          View
                        </button>

                        <button
                          className="edit-btn"
                          onClick={() => handleEdit(project)}
                        >
                          Edit
                        </button>

                        <button
                          className="delete-btn"
                          onClick={() => handleDelete(project.id)}
                        >
                          Delete
                        </button>

                      </td>

                    </tr>

                  ))}

                </tbody>

              </table>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}

export default Projects;