import React from "react";
import Sidebar from "./Sidebar";
import Topbar from "./Topbar";
import "../css/analytics.css";

function Analytics() {
  return (
    <div className="dashboard">

      <Sidebar />

      <div className="dashboard-main">

        <Topbar />

        <div className="dashboard-content">

          <div className="analytics-page">

            <h2>📊 Analytics Dashboard</h2>

            <div className="analytics-cards">

              <div className="analytics-card">
                <h3>Total Enquiries</h3>
                <h1>124</h1>
              </div>

              <div className="analytics-card">
                <h3>Total Clients</h3>
                <h1>52</h1>
              </div>

              <div className="analytics-card">
                <h3>Projects</h3>
                <h1>31</h1>
              </div>

              <div className="analytics-card">
                <h3>Revenue</h3>
                <h1>₹4.5L</h1>
              </div>

            </div>

            <div className="chart-box">

              <h3>Monthly Enquiries</h3>

              <div className="bars">

                <div className="bar">
                  <div style={{height:"40%"}}></div>
                  <span>Jan</span>
                </div>

                <div className="bar">
                  <div style={{height:"70%"}}></div>
                  <span>Feb</span>
                </div>

                <div className="bar">
                  <div style={{height:"50%"}}></div>
                  <span>Mar</span>
                </div>

                <div className="bar">
                  <div style={{height:"90%"}}></div>
                  <span>Apr</span>
                </div>

                <div className="bar">
                  <div style={{height:"60%"}}></div>
                  <span>May</span>
                </div>

                <div className="bar">
                  <div style={{height:"100%"}}></div>
                  <span>Jun</span>
                </div>

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>
  );
}

export default Analytics;